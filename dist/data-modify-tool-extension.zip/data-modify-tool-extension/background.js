chrome.browserAction.onClicked.addListener(function (tab) {
	chrome.tabs.create({'url': "data-modify-tool.html"})
});